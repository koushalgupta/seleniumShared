package testScript;


import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import pageObjects.LandingPage;
import pageObjects.LoginPage;
import resources.Base;

public class PageLoad extends Base{
	public static Logger logging =LogManager.getLogger(PageLoad.class.getName());
	
	@Parameters({"utilFile"})
	@BeforeTest()
	public void initialize(String utilLocation) throws IOException {
		driver = inintializeDriver();
		logging.info("Driver is initialized");

	}
	@Test()
	 public void withoutPayLoad() throws IOException
	    {
	        driver.get(prop.getProperty("url"));
	        driver.manage().window().maximize();
	        logging.info("Navigated to Home page");
	        
	        String user =  prop.getProperty("user");
	        String pass = prop.getProperty("pass");
	        	        
	        LandingPage lp = new LandingPage(driver);
	                
	        System.out.println(lp.noThanks());
	        if(lp.noThanks().isDisplayed()) {
	        	lp.noThanks().click();	 
	        	logging.info("Pop Up Window is close as expected");
	        }
	        
	        Assert.assertEquals(lp.featured().getText(),"FEATURED COURSES");
	        logging.info("Successfully validated Text message");
	        
	        lp.getlogin().click();
	        
	        LoginPage log = new LoginPage(driver);
	        log.emailField().sendKeys(user);
	        log.password().sendKeys(pass);
	        log.logIn().click();
	        Assert.assertEquals("Invalid email or password.", log.invalidmessage().getText());
	        logging.info("Successfully validated Invalid Text message");
	        
	        getScreenshot("ToTest");
			
	    }


	@AfterTest()
	public void cleanup() {
		driver.close();
		driver=null;
	}
	
}
