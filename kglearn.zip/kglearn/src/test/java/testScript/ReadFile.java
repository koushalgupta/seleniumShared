package testScript;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFile {
	static ArrayList<String> excelData = new ArrayList<String>();
	
	public static void main(String[] args) throws IOException {
		
		ArrayList test = getExcelData123("invalidUserName","C:\\Koushal\\workspace\\kglearn\\src\\main\\java\\resources\\data.properties");
	}



	public static ArrayList getExcelData123(String testCase, String utilLocation) throws IOException {
		FileInputStream testngXML = new FileInputStream(utilLocation);
		Properties prop = new Properties();
		prop.load(testngXML);
		
		FileInputStream fis = new FileInputStream(prop.getProperty("testDataLocaiton"));
		XSSFWorkbook book = new XSSFWorkbook(fis);
		for (int i = 0; i < book.getNumberOfSheets(); i++) {
			System.out.println(book.getSheetName(i));
			if (book.getSheetName(i).equalsIgnoreCase("Sheet1")) {
				XSSFSheet sheet = book.getSheetAt(i);
				Iterator<Row> row = sheet.iterator();
				Row firstRow = row.next();
				Iterator<Cell> cell = firstRow.iterator();
				int column=0;
				int k = 0;
				while (cell.hasNext()) {
					Cell cellValue = cell.next();
					System.out.println(cellValue.getStringCellValue());
					if (cellValue.getStringCellValue().equalsIgnoreCase("TestCase")) {
						k=column;
					}
					column++;
				}

				while (row.hasNext()) {
					firstRow = row.next();
					System.out.println(firstRow.getCell(k).getStringCellValue());
					if(firstRow.getCell(k).getStringCellValue().equalsIgnoreCase(testCase)) {						
						Iterator<Cell> cellValue = firstRow.iterator();
						while (cellValue.hasNext()) {
							Cell cellValues = cellValue.next();
							excelData.add(cellValues.getStringCellValue());
						}
					}
					
				}

			}
		}
		
		System.out.println(excelData);
		return excelData;
	}
}
