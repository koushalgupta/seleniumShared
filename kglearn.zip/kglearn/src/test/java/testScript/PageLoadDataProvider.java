package testScript;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import pageObjects.LandingPage;
import pageObjects.LoginPage;
import resources.Base;

public class PageLoadDataProvider extends Base{
	public static Logger logging =LogManager.getLogger(PageLoadDataProvider.class.getName());

	@Test(dataProvider = "getData")
	 public void withPayLoad(String user, String pass) throws IOException
	    {
	        driver = inintializeDriver();
	        logging.info("Driver is initialized");
	        driver.get(prop.getProperty("url"));
	        logging.info("Navigated to Home page");
	        driver.manage().window().maximize();
	        
	        LandingPage lp = new LandingPage(driver);
	        

	        
	        System.out.println(lp.noThanks());
	        if(lp.noThanks().isDisplayed()) {
	        	lp.noThanks().click();	
	        	logging.info("Successfully clicked pop up");
	        }
	        
	        Assert.assertEquals(lp.featured().getText(),"FEATURED COURSES");
	        logging.info("Successfully validated Text message");
	        
	        lp.getlogin().click();
	        
	        LoginPage log = new LoginPage(driver);
	        log.emailField().sendKeys(user);
	        log.password().sendKeys(pass);
	        log.logIn().click();
	        Assert.assertEquals("Invalid email or password.", log.invalidmessage().getText());
	        logging.info("Successfully validated invalid message");
	        driver.close();
	        driver=null;
	    }

	@DataProvider
	public Object[][] getData() {
		Object[][] data = new Object[2][2];
		data [0][0] = "testagain@gmail.com";
		data [0][1] = "pass123";
	
		data [1][0] = "restagain@gmail.com";
		data [1][1] = "pass12345";
		return data;
	}
	
}
