package testScript;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.GuruLandingPage;
import resources.Base;

public class GuruLogin extends Base {

	@Test(groups = { "sanity", "guru" })
	public void guruLogin() throws IOException {
		driver.get(prop.getProperty("guruURL"));
		driver.manage().window().maximize();
		GuruLandingPage gLP = new GuruLandingPage(driver);
		System.out.println(driver.getTitle());
		getScreenshot("GuruLandingPage");
		Assert.assertEquals(driver.getTitle(), "Guru99 Bank Home Page");
		gLP.guruUserId().sendKeys(prop.getProperty("guruUserName"));
		gLP.guruPassword().sendKeys(prop.getProperty("guruPassword"));
		gLP.guruLogin().click();
		System.out.println(driver.getTitle());
		getScreenshot("GuruLoginPage");
		Assert.assertEquals(driver.getTitle(), "Guru99 Bank Manager HomePage");
	}

}
