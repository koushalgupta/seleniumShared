package testScript;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pageObjects.GuruLandingPage;
import pageObjects.GuruHomePage;
import resources.Base;
import resources.FileUtility;

public class GuruLoginTestDataxlsx extends Base {
	GuruLandingPage gLP;
	ArrayList<String> data = new ArrayList<String>();
	@Parameters({ "utilFile" })
	@BeforeTest
	public void setup(String utilLocation) throws IOException {
		System.out.println("utilLocation :" + utilLocation);
		driver = inintializeDriver();
		logging.info("Guru Driver is initialized");
		System.out.println("Before Test");
	}

	@Parameters({ "utilFile" })
	@Test(groups = { "sanity", "guru" })
	public void guruLoginTestData(String utilLocation) throws IOException {
		driver.get(prop.getProperty("guruURL"));
		driver.manage().window().maximize();
		gLP = new GuruLandingPage(driver);
		System.out.println(driver.getTitle());
		getScreenshot("GuruLandingPage");
		Assert.assertEquals(driver.getTitle(), "Guru99 Bank Home Page");
		FileUtility fu = new FileUtility();
		data = fu.getExcelData("validAll",utilLocation);
		login(data);
		data = fu.getExcelData("invalidUserName",utilLocation);
		login(data);
		data = fu.getExcelData("invalidPassword",utilLocation);
		login(data);
		data = fu.getExcelData("invalidAll",utilLocation);
		login(data);

	}

	@AfterTest()
	public void tearDown() {
		driver.close();
		driver = null;
		System.out.println("After Test");
	}
	
	private void login(ArrayList<String> values) throws IOException {
		gLP.guruUserId().sendKeys(values.get(1));
		gLP.guruPassword().sendKeys(values.get(2));
		gLP.guruLogin().click();
		if(values.get(0).contains("invalid")){
			System.out.println(driver.switchTo().alert().getText());
			Assert.assertEquals(driver.switchTo().alert().getText(),"User or Password is not valid",values.get(0)+" scenario working as expected, login failed");
			driver.switchTo().alert().accept();
		}else {
			Assert.assertEquals(driver.getTitle(), "Guru99 Bank Manager HomePage",values.get(0)+" scenario working as expected, login sucessful");
			System.out.println(driver.getTitle());
			GuruHomePage hp = new GuruHomePage(driver);
			String[] manageID = hp.managerText().getText().split(":");
			Assert.assertEquals(manageID[1].trim(), values.get(1));
			hp.logout().click();
			driver.switchTo().alert().accept();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(gLP.guruLoginBY()));
	 
		}		
		data.clear();
	}
}
