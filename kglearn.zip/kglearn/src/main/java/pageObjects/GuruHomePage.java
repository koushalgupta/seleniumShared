package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GuruHomePage {

	public WebDriver driver;
	
	By logout = By.linkText("Log out");
	By managerText = By.xpath("//td[contains(text(),'Manger Id')]");
	
	public GuruHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement managerText() {
		return driver.findElement(managerText);
	}
	
	public WebElement logout() {
		return driver.findElement(logout);
	}
}
