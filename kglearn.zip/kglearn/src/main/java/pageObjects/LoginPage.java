package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	public WebDriver driver;
	
	By emailField = By.id("user_email");
	By password = By.id("user_password");
	By logIn = By.name("commit");
	By invalidmessage = By.cssSelector(".alert,alert-danger");
	
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement emailField() {
		return driver.findElement(emailField);
	}
	
	public WebElement password() {
		return driver.findElement(password);
	}
	
	public WebElement logIn() {
		return driver.findElement(logIn);
	}
	
	public WebElement invalidmessage() {
		return driver.findElement(invalidmessage);
	}
}
