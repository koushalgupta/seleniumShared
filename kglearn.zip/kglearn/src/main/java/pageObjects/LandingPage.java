package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	
	public WebDriver driver;
	
	By sigin = By.cssSelector("a[href*='sign_in']");
	
	By noThanks = By.xpath("//button[contains(text(),'NO THANKS')]");
	
	By featured = By.xpath("//*[contains(text(),'Featured Courses')]");
	
	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement noThanks() {
		return driver.findElement(noThanks);
	}

	public WebElement featured() {
		return driver.findElement(featured);
	}

	public WebElement getlogin() {
		return driver.findElement(sigin);
	}

}
