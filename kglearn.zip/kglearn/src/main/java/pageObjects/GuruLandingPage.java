package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GuruLandingPage {
	
	WebDriver driver;
	By guruUserId = By.name("uid");
	By guruPassword = By.name("password");
	By guruLogin = By.cssSelector("[value='LOGIN']");
	
	public GuruLandingPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement guruUserId() {
		return driver.findElement(guruUserId);
	}

	public WebElement guruPassword() {
		return driver.findElement(guruPassword);
	}
	
	public WebElement guruLogin() {
		return driver.findElement(guruLogin);
	}
	
	public By guruLoginBY() {
		return guruLogin;
	}
}
