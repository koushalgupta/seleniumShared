package resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileUtility extends Base{
	static ArrayList<String> data = new ArrayList<String>();

	public ArrayList getExcelData(String testCase, String utilLocation) throws IOException {
		FileInputStream testngXML = new FileInputStream(utilLocation);
		Properties prop = new Properties();
		prop.load(testngXML);
		
		FileInputStream fis = new FileInputStream(prop.getProperty("testDataLocaiton"));
		XSSFWorkbook book = new XSSFWorkbook(fis);
		for (int i = 0; i < book.getNumberOfSheets(); i++) {
			System.out.println(book.getSheetName(i));
			if (book.getSheetName(i).equalsIgnoreCase("Sheet1")) {
				XSSFSheet sheet = book.getSheetAt(i);
				Iterator<Row> row = sheet.iterator();
				Row firstRow = row.next();
				Iterator<Cell> cell = firstRow.iterator();
				int column=0;
				int k = 0;
				while (cell.hasNext()) {
					Cell cellValue = cell.next();
					System.out.println(cellValue.getStringCellValue());
					if (cellValue.getStringCellValue().equalsIgnoreCase("TestCase")) {
						k=column;
					}
					column++;
				}

				while (row.hasNext()) {
					firstRow = row.next();
					System.out.println(firstRow.getCell(k).getStringCellValue());
					if(firstRow.getCell(k).getStringCellValue().equalsIgnoreCase(testCase)) {						
						Iterator<Cell> cellValue = firstRow.iterator();
						while (cellValue.hasNext()) {
							Cell cellValues = cellValue.next();
							data.add(cellValues.getStringCellValue());
						}
					}
					
				}

			}
		}
		
		System.out.println(data);
		return data;
		}
	
	public static ArrayList<String> getDBData(String scenario) throws SQLException{

		Connection  connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/kgtest", "root", "Acc1234$$");
		Statement squery= connect.createStatement();
		ResultSet rs = squery.executeQuery("select * from kgtest where scenario ='validAll'");
		
		while(rs.next()) {
			System.out.println(rs.getString("username"));
			System.out.println(rs.getString("password"));
			data.add(rs.getString("username"));
			data.add(rs.getString("password"));
		}
		return data;
		
	}
}
