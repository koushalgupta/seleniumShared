package resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Base 
{
	public static Logger logging =LogManager.getLogger(Base.class.getName());
	public static WebDriver driver;
	public static Properties prop;
	public static final String propertyFileLocation = "C:\\Koushal\\workspace\\kglearn\\src\\main\\java\\resources\\data.properties";

	public WebDriver inintializeDriver() throws IOException {
		prop = new Properties();
		FileInputStream fis = new FileInputStream(propertyFileLocation);
		prop.load(fis);
		String browser = prop.getProperty("browser");
		
		if(browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", prop.getProperty("fireFoxDriver"));
			driver=new ChromeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}
   
	public void getScreenshot(String result) throws IOException
	{
		logging.info("Taking Snapshots");
		Random rand = new Random(); 
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C://Koushal//shots//"+result+"screenshot"+rand.nextInt(1000)+".png"));
	}

}
